import React from "react";
import "./App.css";

import Router from "./routes";

export default function MainApp() {
  return (
    <>
      <Router />
    </>
  );
}
