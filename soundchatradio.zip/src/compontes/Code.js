// import './css/style.css';
import FbGridImages from './Images'

export default FbGridImages;